# clam, R code for classical (non-Bayesian) age-depth modelling, this version 1.0.2
# Maarten Blaauw <maarten.blaauw@qub.ac.uk>
# see accompanying manual.html and Blaauw (Quaternary Geochronology 2010)

calcurvename <- "IntCal09.14C" # default calibration curve (see choosecurve function)

# this is the main age-depth modelling function
# the default values for the options can be changed here or when calling clam
# be sure to maintain the order of the options, or to update changes in lines 10&14
clam <- function(name="Example", type=1, smooth=c(), sdev=2, its=1000, wghts=1, outliers=c(), ignore=c(), est=1, mixed.effect=FALSE, calmin=c(), calmax=c(), steps=1, BCAD=FALSE, dmin=c(), dmax=c(), every=1, ageofdepth=c(), depth="cm", depthseq=c(), thickness=1, hiatus=c(), remove.reverse=0.5, times=5, sep=",", ext=".csv", runname=c(), storedat=FALSE, calhght=1, calcol=rgb(0,0,1,0.5), plotrange=TRUE, plotpdf=TRUE, plotpng=TRUE, greyscale=c(), xlab=c(), ylab=c(), detcol=rgb(0,0,1,.5), outcol="red", outlsize=1, bestcol="black", rangecol=rgb(0,0,0,.3))
  .clam(name, type, smooth, sdev, its, wghts, outliers, ignore, est, mixed.effect, calmin, calmax, steps, BCAD, dmin, dmax, every, ageofdepth, depth, depthseq, thickness, hiatus, remove.reverse, times, sep, ext, runname, storedat, calhght, calcol, plotrange, plotpdf, plotpng, greyscale, xlab, ylab, detcol, outcol, outlsize, bestcol, rangecol)


.clam <- function(name, type, smooth, sdev, its, wghts, outliers, ignore, est, mixed.effect, calmin, calmax, steps, BCAD, dmin, dmax, every, ageofdepth, depth, depthseq, thickness, hiatus, remove.reverse, times, sep, ext, runname, storedat, calhght, calcol, plotrange, plotpdf, plotpng, greyscale, xlab, ylab, detcol, outcol, outlsize, bestcol, rangecol)
  {
    # avoid Windows habit of silently adding .txt extension to text files
    win <- list.files(paste("Cores/", name, sep=""), pattern=".csv.txt")
    if(length(win) > 0)
      {
        cat("\nRemoving .txt extension from file", win[1], "\n")
        file.rename(paste("Cores/", name, "/", name, ".csv.txt", sep=""),
        paste("Cores/", name, "/", name, ".csv", sep=""))
      }

    # adapt the calibration curve to BC/AD if desired
    if(BCAD) calcurve[,1] <- 1950-calcurve[,1]
    if(length(xlab)==0) xlab <- ifelse(BCAD, "cal BC/AD", "cal BP")
    cat(paste("Core name:", name))
    if(length(greyscale)>0) storedat <- TRUE
    dat <- .read.clam(name, ext, steps, sdev, times, sep, BCAD, calcurve, storedat, ignore, thickness)
    cat("\n Calibrating dates... ")

    # calculate the depths to be used, based on the ranges and resolution
    if(length(dmin)==0) dmin <- min(dat$depth)
    if(length(dmax)==0) dmax <- max(dat$depth)
    if(length(depthseq) < 1) depthseq <- seq(dmin, dmax, by=every)
    if(file.exists(dd <- paste("Cores/", name, "/", name, "_depths.txt", sep="")))
      depthseq <- sort(unique(c(depthseq, read.table(dd)[,1]))) # for EPD
    if(length(ageofdepth) > 0)
      depthseq <- sort(unique(c(ageofdepth, depthseq)))
    calhght <- calhght * (dmax-dmin) / 50

    # decide which models and point estimates should be used
    if(any(type==c(1, "int", "inter", "interp"))) type <- 1 else
    if(any(type==c(2, "reg", "regr", "poly", "polyn"))) type <- 2 else
    if(any(type==c(3, "spline", "spl"))) type <- 3 else
    if(any(type==c(4, "smooth", "sm"))) type <- 4 else
    if(any(type==c(5, "loess", "lowess"))) type <- 5
    if(est==1 || est==2) Est <- dat$mid else # 1 dummy, calculated later
    if(est==3) Est <- dat$mid else
    if(est==4) Est <- dat$wmn else
    if(est==5) Est <- dat$med else
    if(est==6) Est <- dat$mode

    # remove outliers from the age-depth modelling
    if(length(outliers) > 0)
      {
        depths <- dat$depth[-outliers]
        errors <- dat$error[-outliers]
        calibs <- dat$calib[-outliers]
        Est <- Est[-outliers]
      }else
      {
        depths <- dat$depth
        errors <- dat$error
        calibs <- dat$calib
      }

  # age-depth modelling with curves through sampled age estimates
  # in sections if one or more hiatuses are present
    if(length(hiatus) > 0)
      {
        allrange <- c(0,0,0,0)
        hiatusseq <- sort(c(range(depthseq), hiatus))
        for(i in 2:length(hiatusseq))
          {
            cat(paste("\n section ", i-1, ",", sep=""))
            section <- depthseq[min(which(depthseq >= hiatusseq[i-1])) : max(which(depthseq <= hiatusseq[i]))]
            if(i>2) section <- section[-1]
            sel <- min(which(depths >= min(section))):max(which(depths <= max(section)))
            if(mixed.effect) smp <- .mixed.effect(its, depths, dat, Est, calcurve, steps) else
              smp <- .smpl(its, depths[sel], calibs[sel], Est[sel])
            calrange <- .model.clam(type, smooth, its, wghts, depths[sel], errors[sel], section, sdev, est, dat, smp, greyscale, remove.reverse, storedat, ageofdepth, BCAD)
            allrange <- rbind(allrange, calrange)
          }
        calrange <- allrange[2:nrow(allrange),]
      } else
      {
        if(mixed.effect)
          smp <- .mixed.effect(its, depths, dat, Est, calcurve, steps) else
          smp <- .smpl(its, depths, calibs, Est)
        calrange <- .model.clam(type, smooth, its, wghts, depths, errors, depthseq, sdev, est, dat, smp, greyscale, remove.reverse, storedat, ageofdepth, BCAD)
      }
    dat$model <- approx(calrange[,1], (calrange[,2]+calrange[,3])/2, dat$depth)$y

    if(est==2) calrange[,4] <- (calrange[,2]+calrange[,3])/2
    if(!BCAD && any(diff(calrange[,4]) < 0) || BCAD && any(diff(calrange[,4]) > 0))
    reversal <- TRUE else reversal <- FALSE
    gfit <- round(.gfit(calcurve, dat, calrange, outliers), 2)

    # produce the age-depth plot, and a pdf copy if desired
    if(length(calmin)==0) calmin <- min(dat$mid, calrange[,2])
    if(length(calmax)==0) calmax <- max(dat$mid, calrange[,3])
    if(length(ageofdepth > 0)) layout(matrix(c(1,2,1,3), nrow=2), heights=c(.7,.3))
    .ageplot(calmin, calmax, dmin, dmax, xlab, ylab, hiatus, depthseq, outliers, plotrange, BCAD, greyscale, if(length(greyscale)>0) chron else c(), detcol, outcol, outlsize, bestcol, rangecol, dat, calrange, depth, calhght, calcol)

    # write files providing calibrated dates, age-model and settings
    colnames(calrange) <- c("Depth", paste("min.", sdev, "sd", sep=""), paste("max.", sdev, "sd", sep=""), "point")
    .write.clam(dat, runname, calrange, name, sdev, type, remove.reverse, smooth, wghts, its, outliers, ignore, est, BCAD, steps, every, depth, depthseq, hiatus, gfit, reversal, plotpdf, plotpng, calmin, calmax, dmin, dmax, xlab, ylab, plotrange, greyscale, if(length(greyscale)>0) chron else c(), detcol, outcol, outlsize, bestcol, rangecol, calhght, calcol)
    closeAllConnections()

    if(storedat)
      {
        calrange <<- calrange
        dat <<- dat
        smp <<- smp
      }

    # plot the age distribution of a provided depth
    if(length(ageofdepth > 0))
      {
        xlim <- range(.ageofdepth)
        if(!BCAD) xlim <- xlim[2:1]
        hst <- density(.ageofdepth, n=max(1, max(xlim)-min(xlim)))
        yr <- seq(min(xlim), max(xlim), by=steps)
        hst <- cbind(c(yr, max(xlim), min(xlim)), c(approx(hst$x, hst$y, yr)$y, 0, 0))
        plot(hst, type="n", main="", xlim=xlim, xlab=xlab, ylab="")
        polygon(hst, col="grey")
        legend("topleft", paste(ageofdepth, depth), bty="n")
        layout(matrix(1))
        rng <- round(calrange[max(which(calrange[,1] <= ageofdepth)),])
        cat("\n  Age range of ", ageofdepth, " ", depth, ": ", rng[3], " to ", rng[2], ifelse(BCAD, " cal BC/AD", " cal BP"), " (", rng[3]-rng[2], " yr, ", sdev, " sd)",  sep="")
      }

    # report the confidence ranges, the goodness-of-fit, and whether any age-reversals occurred
    rng <- round(calrange[,3]-calrange[,2])
    cat("\n  ", name, "'s ", sdev, " sd ranges span from ", min(rng), " to ", max(rng), " yr (average ", round(mean(rng)), " yr)", sep="")
    cat("\n  Fit (-log, lower is better):", gfit, "\n")
    if(reversal) cat("  Age reversals occurred. Try other model?\n")
  }


  # load the default (cc) or another calibration curve (curves should reside in current folder)
choosecurve <- function(default=FALSE, pattern=".14C", cc=calcurvename)
  {
    if(default) chosen <- cc else
      {
        whichcurves <- list.files(pattern=pattern)
        cat("Give number of alternative curve:")
        chosen <- select.list(whichcurves)
      }
    calcurve <<- read.table(chosen)
    calcurvename <<- chosen
    cat(paste(" Using ", chosen, " as calibration curve.\n", sep=""))
  }


# find the calibrated distributions of 14C dates
.caldist <- function(cage, error, steps, times, calcurve, BCAD)
  {
    # find relevant section of the calibration curve
    whichmin <- min(which(calcurve[,2]+calcurve[,3] >= cage-max(100, (times*error))), 1)
    whichmax <- max(which(calcurve[,2]-calcurve[,3] <= cage+max(100, (times*error))), nrow(calcurve))
    theta <- seq(calcurve[whichmin,1], calcurve[whichmax,1], by=ifelse(BCAD, -steps, steps))

    # find 14C ages corresponding to the calendar ages
    mu <- approx(calcurve[,1], calcurve[,2], theta)$y
    cerror <- approx(calcurve[,1], calcurve[,3], theta)$y

    # calibrate; find how far the determination's 14C age is from that of the curve
    cal <- dnorm(mu, cage, (error^2+cerror^2)^.5)
    calib <- cbind(theta, cal/sum(cal))
    if(BCAD)
      calib[calib[,1] <= 0,1] <- calib[calib[,1] <= 0,1] -1

    # only report those normalised calibrated probabilities beyond a treshold
    calib[calib[,2] > 1e-6,]
  }


# find the highest posterior density (hpd) of the calibrated distribution
.hpd <- function(dat, sdev, steps)
  {
    # rank the ages according to their calibrated distribution probabilities
    o <- order(dat[,2], decreasing=TRUE)
    dat <- cbind(dat[o,1], dat[o,2])
    # only retain those ages with cumulative normalised probabilities within sdev/percentage
    ord <- which(cumsum(dat[,2]) <= (pnorm(sdev)-pnorm(-sdev)))
    dat <- dat[ord,]
    o <- order(dat[,1])
    dat <- cbind(dat[,1][o], dat[,2][o])
    # identify any individual ranges within the hpd range and calculate their probability
    dif <- which(diff(dat[,1]) > steps)
    if(length(dif)==0)
      hpds <- cbind(dat[1,1], dat[nrow(dat),1], 100) else
      {
        dif <- c(dat[1,1], sort(c(dat[dif,1], dat[dif+1,1])), dat[nrow(dat),1])
        dif <- matrix(dif, ncol=2, byrow=TRUE)
        probs <- c()
        for(i in 1:nrow(dif))
          probs[i] <- round(100*sum(dat[which(dat[,1]==dif[i,1]):which(dat[,1]==dif[i,2]),2]),1)
        hpds <- cbind(dif, probs)
      }
  }


# calculate the age-depth model and its uncertainty
.model.clam <- function(type, smooth, its, wghts, depths, errors, depthseq, sdev, est, dat, smp, greyscale, remove.reverse, storedat, ageofdepth, BCAD)
  {
    # warn for extrapolation, refuse to do so for loes spline
    if(min(depthseq) < min(dat$depth) || max(depthseq) > max(dat$depth))
    if(type==5)
      stop(" cannot extrapolate using loess! Change settings.\n ") else
      cat(" extrapolating beyond dated levels, dangerous!\n ")

    # choose model: interpolation, (polynomial) regression, spline, smooth spline or loess
    chron <- array(0, dim=c(length(depthseq), its))
    if(type==1) chron <- .interp(depthseq, depths, its, chron, smp) else
    if(type==2) chron <- .poly(depthseq, smooth, wghts, errors, depths, its, chron, smp) else
    if(type==3) chron <- .spline(depthseq, smooth, depths, its, chron, smp) else
    if(type==4) chron <- .smooth(depthseq, smooth, wghts, errors, depths, its, chron, smp) else
    if(type==5) chron <- .loess(depthseq, smooth, wghts, errors, depths,  its, chron, smp)

    # test against age reversals
    warp <- c()
    if(remove.reverse!=FALSE)
      for(i in 1:ncol(chron))
        if((!BCAD && min(diff(chron[,i])) <= 0) || (BCAD && max(diff(chron[,i])) >= 0))
          warp <- c(warp, i)
    if(length(warp) > 0)
      {
        if(length(warp) > remove.reverse*its)
          cat("\n\n !!! Too many models with age reversals!!!\n") else
	    {
	      cat("\n Removing", length(warp), "models with age reversals,", its-length(warp), "models left...")
	      chron <- chron[,-warp]
	      smp <- smp[,-warp,]
	    }
      }

    if(length(ageofdepth) > 0)
      if(ageofdepth %in% depthseq)
        .ageofdepth <<- chron[which(depthseq==ageofdepth),]

    if(storedat)
      {
        chron <<- chron
        smp <<- smp
      }

    # find hpd uncertainty ranges of calendar age for each depth of the core
    # based on histogram of assigned calendar ages from all iterations
    calrange <- array(0, dim=c(nrow(chron), 2))
    wm <- c()
    for(i in 1:nrow(chron))
      {
        temp <- density(x <- chron[i,2:ncol(chron)], n=max(1,(max(x)-min(x))))
        if(est==1) wm[i] <- weighted.mean(temp$x, temp$y)
        yrs <- seq(min(temp$x), max(temp$x), by=1)
        temp <- cbind(yrs, approx(temp$x, temp$y, yrs)$y)
        o <- order(temp[,2], decreasing=TRUE)
        temp <- cbind(temp[o,1], cumsum(temp[o,2])/sum(temp[,2]))
        calrange[i,] <- range(temp[which(temp[,2] <= (pnorm(sdev)-pnorm(-sdev))),1])
      }
    if(est==1)
      cbind(depthseq, cbind(calrange, wm)) else
      cbind(depthseq, cbind(calrange, chron[,1]))
  }


# sample point age estimates from the calibrated distributions ('its' times)
# the probability of a year being sampled is proportional to its calibrated probability
# suppressWarnings is to suppress a warning about new method being used at first use smp
.smpl <- function(its, depths, calibs, Est)
  {
    smp <- array(1, dim=c(length(depths), 1+its,2))
    smp[,1,1] <- Est
    for(i in 1:length(calibs))
      smp[i,(1:its)+1,] <-
        calibs[[i]][suppressWarnings(sample(1:length(calibs[[i]][,1]), its, prob=calibs[[i]][,2], TRUE)),]
    smp
  }


# akin to Heegaard et al.'s mixed effect modelling, but using calibrated dates
.mixed.effect <- function(its, depths, dat, Est, calcurve, steps)
  {
    cat("\n Mixed effect modelling, this will take some time")
    smp <- array(1, dim=c(length(depths), 1+its, 2))
    smp[,1,1] <- Est
    for(i in 1:length(dat$depth))
      if(!is.na(dat$cal[[i]]))
        smp[i,(1:its)+1,1] <- rnorm(its, dat$cal[[i]], dat$error[[i]]) else
        for(j in 1:its)
          {
            if(j/(its/3) == round(j/(its/3))) cat(".")
            yr <- rnorm(1, dat$cage[[i]]-dat$res[[i]], dat$error[[i]])
            yr <- cbind(calcurve[,1], dnorm(calcurve[,2], yr, sqrt(dat$error[[i]]^2+calcurve[,3]^2)))
            yr <- yr[yr[,2]>0,]
            yr <- approx(yr[,1], yr[,2], seq(min(yr[,1]), max(yr[,1]), by=steps))
            smp.yr <- sample(length(yr$x), 1, prob=yr$y)
            smp[i,j+1,] <- c(yr$x[smp.yr], yr$y[smp.yr])
          }
    smp
  }


# interpolate linearly between the data
.interp <- function(depthseq, depths, its, chron, smp)
  {
    cat(" Interpolating, sampling")
    for(i in 1:its)
      {
        temp <- approx(depths, smp[,i,1], depthseq, ties=mean)$y

        # allow for extrapolation... dangerous!
        if(min(depthseq) < min(depths))
          {
            minus <- which(depthseq < min(depths))
            slope <- diff(temp)[max(minus)+1]/diff(depthseq)[max(minus)+1]
            temp[minus] <- temp[max(minus)+1] + slope * (depthseq[minus] - min(depths))
          }
        if(max(depthseq) > max(depths))
          {
            maxim <- which(depthseq > max(depths))
            slope <- diff(temp)[min(maxim)-2]/diff(depthseq)[min(maxim)-2]
            temp[maxim] <- temp[min(maxim)-1] + slope * (depthseq[maxim] - max(depths))
          }
        chron[,i] <- temp
        if(i/(its/5) == round(i/(its/5))) cat(".")
      }
    chron
  }


# polynomial regressions of certain order through the data (default linear, y=ax+b)
.poly <- function(depthseq, smooth, wghts, errors, depths, its, chron, smp)
  {
    if(length(smooth)==0)
      cat(" Using linear regression, sampling") else
      cat(paste(" Using polynomial regression (degree ", smooth, "), sampling", sep=""))
    if(wghts==0) w <- c() else w <- 1/errors^2
    for(i in 1:its)
      {
        if(wghts==1) w <- smp[,i,2]
        chron[,i] <- predict(lm(smp[,i,1] ~ poly(depths, max(1, smooth))), data.frame(depths=depthseq), weights=w)
        if(i/(its/5) == round(i/(its/5))) cat(".")
      }
    chron
  }


# fit cubic spline interpolations through the data
.spline <- function(depthseq, smooth, depths, its, chron, smp)
  {
    if(length(smooth) < 1) smooth <- .3
    cat(paste(" Using cubic spline sampling", sep=""))
    for(i in 1:its)
      {
        chron[,i] <- spline(depths, smp[,i,1], xout=depthseq)$y
        if(i/(its/5) == round(i/(its/5))) cat(".")
      }
    chron
  }


# fit cubic smoothed splines through the data, with smoothing factor
.smooth <- function(depthseq, smooth, wghts, errors, depths, its, chron, smp)
  {
    if(length(smooth) < 1) smooth <- .3
    cat(paste(" Using smoothing spline (smoothing ", smooth, "), sampling", sep=""))
    if(wghts==0) w <- c() else w <- 1/errors^2
    for(i in 1:its)
      {
        if(wghts==1) w <- smp[,i,2]
        chron[,i] <- predict(smooth.spline(depths, smp[,i,1], w=w, spar=smooth), depthseq)$y
        if(i/(its/5) == round(i/(its/5))) cat(".")
      }
    chron
  }


# fit locally weighted (1/errors^2) splines through the data, with smoothing factor
.loess <- function(depthseq, smooth, wghts, errors, depths, its, chron, smp)
  {
    if(length(smooth) < 1) smooth <- .75
    cat(paste(" Using loess (smoothing ", smooth, "), sampling", sep=""))
    if(wghts==0) w <- c() else w <- 1/errors^2
    for(i in 1:its)
      {
        if(wghts==1) w <- smp[,i,2]
        chron[,i] <- predict(loess(smp[,i,1] ~ depths, weights=w, span=smooth), depthseq)
        if(i/(its/5) == round(i/(its/5))) cat(".")
      }
    chron
  }


# read the data and perform first calculations incl. calibrations
.read.clam <- function(name, ext, steps, sdev, times, sep, BCAD, calcurve, storedat, ignore, thickness)
  {
    # read the file with the dating information and check for common errors
    dat <- list(coredir=paste("Cores/", name, "/", sep=""))
    dets <- read.table(paste(dat$coredir, name, ext, sep=""), comment.char="", header=TRUE, sep=sep, na.strings = c("#N/A!", "NA", "@NA"))
    dets <<- dets
    x <- 0
    for(i in 2:7) if(is.factor(dets[,i])) x <- 1
    if(x==1) stop(paste("\n Some value fields in ", name, ".csv contain letters, please adapt", sep=""), call.=FALSE)
    if(length(dets[is.na(dets[,2]),2])+length(dets[is.na(dets[,3]),3]) != nrow(dets))
      stop(paste("\n Remove duplicate entries within the C14 and calendar fields in ", name, ".csv", sep=""), call.=FALSE)

    if(length(ignore) > 0)
      {
        dat$ignore <- as.character(dets[ignore,1])
        dets <- dets[-ignore,]
      }
    dets <- dets[,1:7]

    dets[is.na(dets[,7]),7] <- thickness
    if(min(dets[,4]) <= 0)
      stop(paste("\n Quoted errors should be larger than zero. Please adapt file ", name, ".csv", sep=""), call.=FALSE)
    dat$ID <- as.character(dets[,1])

    # correct for any reservoir effect
    dets[is.na(dets[,5]),5] <- 0
    dat$cage <- dets[,2] - dets[,5]
    dat$error <- dets[,4]

    # check if any 14C dates lie (entirely or partly) beyond the calibration curve
    outside <- which(!is.na(dat$cage))
    rangecc <- c(min(calcurve[,2]-calcurve[,3]),max(calcurve[,2]+calcurve[,3]))
    outside <- outside[c(which(dat$cage[outside]-times*dat$error[outside] < rangecc[1]), which(dat$cage[outside]+times*dat$error[outside] > rangecc[2]))]
    if(length(outside) > 0)
      {
        truncate <- 0
        for(i in 1:length(outside)) # check if date lies only partly beyond the curve limits
          if((dat$cage[outside[i]]-times*dat$error[outside[i]] < rangecc[1] &&
            dat$cage[outside[i]]+times*dat$error[outside[i]] > rangecc[1]) ||
            (dat$cage[outside[i]]-times*dat$error[outside[i]] < rangecc[2] &&
            dat$cage[outside[i]]+times*dat$error[outside[i]] > rangecc[2]))
              truncate <- truncate + 1
        if(truncate > 0)
          cat("\n Warning, dates spanning beyond the calibration curve will be truncated! ")

        # remove dates which lie entirely outside the limits of the calibration curve
        outside <- outside[c(which(dat$cage[outside]+sdev*dat$error[outside] < rangecc[1]), which(dat$cage[outside]-sdev*dat$error[outside] > rangecc[2]))]
        if(length(outside) > 0)
          {
            cat("\n Warning, dates older than the calibration curve will be ignored! ")
            dets <- dets[-outside,]
            dat$cage <- dat$cage[-outside]
            dat$error <- dat$error[-outside]
            dat$outside <- dat$ID[outside]
            dat$ID <- dat$ID[-outside]
          }
      }

    # fill the 'dat' list with additional information
    dat$cal <- dets[,3]
    dat$res <- dets[,5]
    dat$depth <- dets[,6]
    dat$thick <- dets[,7]

    # find distribution (calibrated if 14C) and point estimates for each date
    for(i in 1:length(dat$depth))
      {
        if(is.na(dat$cage[[i]]))
          {
            age <- dat$cal[[i]]
            error <- dat$error[[i]]
            ageseq <- seq(age-(times*error), age+(times*error), by=steps)
            calib <- cbind(ageseq, dnorm(ageseq, age, error))
          } else
            calib <- .caldist(dat$cage[[i]], dat$error[[i]], steps, times, calcurve, BCAD)
        dat$calib[[i]] <- calib
        dat$hpd[[i]] <- .hpd(calib, sdev=sdev, steps=steps)
        dat$mid[[i]] <- (dat$hpd[[i]][1] + dat$hpd[[i]][2*nrow(dat$hpd[[i]])])/2
        dat$wmn[[i]] <- weighted.mean(calib[,1], 1/calib[,2])
        dat$med[[i]] <- calib[max(which(cumsum(calib[,2]) <= .5)),1]
        dat$mode[[i]] <- calib[which(calib[,2] == max(calib[,2])),1][1]
      }
    if(storedat) dets <<- dets
    dat
  }


# calculate goodness-of-fit (small number, so calculate its -log)
.gfit <- function(calcurve, dat, calrange, outliers)
  {
    gfit <- c()
    if(length(outliers) > 0)
      {
        dat$cage <- dat$cage[-outliers]
        dat$error <- dat$error[-outliers]
        dat$cal <- dat$cal[-outliers]
      }
    gfit <- pnorm(dat$cal, dat$model, dat$error^2)
    if(length(c14 <- which(!is.na(dat$cage))) > 0)
      {
        gfit.c <- approx(calcurve[,1], calcurve[,2], dat$model[c14])$y
        gfit.var <- dat$error[c14]^2 + approx(calcurve[,1], calcurve[,3], dat$model[c14])$y^2
        gfit[c14] <- pnorm(dat$cage[c14], gfit.c, sqrt(gfit.var))
      }
    dat$gfit <- -sum(log(gfit[!is.na(gfit)]))
  }


# write files of the age-depth model, calibrated ranges, and settings
.write.clam <- function(dat, runname, calrange, name, sdev, type, remove.reverse, smooth, wghts, its, outliers, ignore, est, BCAD, steps, every, depth, depthseq, hiatus, gfit, reversal, plotpdf, plotpng, calmin, calmax, dmin, dmax, xlab, ylab, plotrange, greyscale, chron, detcol, outcol, outlsize, bestcol, rangecol, calhght, calcol)
  {
    # age-depth model; age estimates and ranges for every analysed depth
    runnames <- c("_interpolated", "_polyn_regr", "_cubic_spline", "_smooth_spline", "_loess")
    ifelse(length(runname)==0, runname <- runnames[type], runname)
    if(file.exists(dd <- paste("Cores/", name, "/", name, "_depths.txt", sep="")))
      {
	dd <- read.table(dd)[,1]
	write.table(calrange[which(duplicated(c(dd, calrange[,1])))-length(dd),], paste(dat$coredir, name, runname, "_ages.txt", sep=""), row.names=FALSE, col.names=c("depth","calmin","calmax","best"), quote=FALSE, sep="\t")
      } else
    write.table(calrange, paste(dat$coredir, name, runname, "_ages.txt", sep=""), row.names=FALSE, col.names=c("depth","calmin","calmax","best"), quote=FALSE, sep="\t")

    # calibrated ranges of all dates
    hpd.file <- file(paste(dat$coredir, name, "_calibrated.txt", sep=""), "w")
    cat(paste("Calibrated age ranges at", sdev, "standard deviation\n"), file=hpd.file)
    for(i in 1:length(dat$depth))
      {
        cat(paste("\n\nDepth: ", dat$depth[[i]], "\ncalmin\tcalmax\tprobability\n"), file=hpd.file)
        hpds <- dat$hpd[[i]]
        for(j in 1:nrow(hpds))
          {
            for(k in 1:3) cat(hpds[j,k], "\t", file=hpd.file)
            cat("\n", file=hpd.file)
          }
      }
    close(hpd.file)

    # relevant settings and results
    set.file <- file(paste(dat$coredir, name, runnames[type], "_settings.txt", sep=""), "w")
    cat(paste("Settings (square brackets give names of the constants)\n\n",
      "Calibration curve: ", calcurvename, "\nAge-depth model: ",
      if(type==1) "linear interpolation between dated levels [type=1]" else
      if(type==2) ifelse(length(smooth==0), "linear regression [type=2] [smooth=TRUE]",
      paste("polynomial regression [type=2] of order", smooth, "[smooth]")) else
      if(type==3) "cubic spline [type=3]" else
      if(type==4) {paste("smooth spline [type=4] with spar =", ifelse(length(smooth)<1, 0.3, smooth), "[smooth]")} else
      if(type==5) {paste("locally weighted spline [type=5] with span =", ifelse(length(smooth)<1, 0.75, smooth), "[smooth]")},
      if(wghts==1) "\nWeighted by the calibrated probabilities [wghts=1]",
      if(wghts==2) "\nWeighted by the errors (1/sdev^2) [wghts=2]",
      "\nCalculations at ", sdev, " standard deviation(s) [sdev=", sdev, "]",
      "\nAmount of iterations: ", its, " [its]",
      "\nCalendar age point estimates for depths based on ",
      if(est==1) "weighted average of all age-depth curves [est=1]" else
      if(est==2) "midpoints of the hpd ranges of the age-depth curves [est=2]" else
      if(est==3) "midpoints of the hpd ranges of the dated levels [est=3]" else
      if(est==4) "weighted means of the dated levels [est=4]" else
      if(est==5) "medians of the dated levels [est=5]" else
      if(est==6) "modes/maxima/intercepts of the dated levels [est=6]",
      "\nCalendar scale used: ", if(BCAD) "cal BC/AD" else "cal BP",
      " [BCAD=", BCAD, "] at a resolution of ", steps, " yr [steps]",
      "\nAges were calculated every ", every, " [every] ", depth,
      " [depth], from ", min(depthseq), " [dmin] to ", max(depthseq), " [dmax] ", depth, sep=""), file=set.file)
    if(length(outliers) > 0)
      {
        cat("\n\nDates assumed outlying [outliers]: ", file=set.file)
        for(i in outliers) cat(i, " (", dat$ID[i], ") ", sep="", file=set.file)
      }
    if(length(ignore) > 0)
      {
        cat("\n\nDates ignored [ignore]: ", file=set.file)
        for(i in 1:length(ignore)) cat(ignore[i], " (", dat$ignore[i], ") ", sep="", file=set.file)
      }
    if(length(dat$outside) > 0)
      {
        cat("\n\nDates outside calibration curve and ignored: ", file=set.file)
        for(i in 1:length(dat$outside)) cat(dat$outside[i], " ", sep="", file=set.file)
      }
    cat(paste(
      if(length(hiatus) > 0)
        paste("\nA hiatus was inferred at", hiatus, depth, "[hiatus]"),
        "\n\nGoodness-of-fit (-log, lower is better): ", gfit,
      if(reversal) "\nSome age-depth reversals occurred"),
      if(remove.reverse) "\nAny models with age-depth reversals were removed",
      "\n\nProduced ", date(), sep="", file=set.file)
    close(set.file)

    if(plotpdf)
      {
        pdf(file=paste(dat$coredir, name, runname, ".pdf", sep=""))
        .ageplot(calmin, calmax, dmin, dmax, xlab, ylab, hiatus, depthseq, outliers, plotrange, BCAD, greyscale, if(length(greyscale)>0) chron else c(), detcol, outcol, outlsize, bestcol, rangecol, dat, calrange, depth, calhght, calcol)
        dev.off()
      }
    if(plotpng)
      {
        png(file=paste(dat$coredir, name, runname, ".png", sep=""))
        .ageplot(calmin, calmax, dmin, dmax, xlab, ylab, hiatus, depthseq, outliers, plotrange, BCAD, greyscale, if(length(greyscale)>0) chron else c(), detcol, outcol, outlsize, bestcol, rangecol, dat, calrange, depth, calhght, calcol)
        dev.off()
      }
  }


.ageplot <- function(calmin, calmax, dmin, dmax, xlab, ylab, hiatus, depthseq, outliers, plotrange, BCAD, greyscale, chron, detcol, outcol, outlsize, bestcol, rangecol, dat, calrange, depth, calhght, calcol)
  {
    # set up initial parameters
    if(length(ylab)==0) ylab <- paste("Depth (", depth, ")", sep="")
    ifelse(BCAD, xlim <- c(calmin, calmax), xlim <- c(calmax, calmin))
    par(xaxt="s", xaxs="r", yaxt="s", yaxs="r", bty="l", mar=c(3,3,.5,.5), mgp=c(1.5,.5,0), font=2)
    plot(0, type="n", xlim=xlim, ylim=c(dmax, dmin), xlab=xlab, ylab=ylab)

    # draw histograms of all age-depth models. Off by default, time-consuming!
    if(length(greyscale)==1)
      {
	plotrange <- FALSE
	depgr=seq(dmin, dmax, length=greyscale)
        for(i in 2:greyscale)
          {
            temp <- density(chron[max(which(calrange[,1]<=depgr[i])),2:ncol(chron)], n=greyscale)
            image(temp$x, c(depgr[i-1], depgr[i]), matrix(temp$y), col=grey(1-(0:100)/100), add=TRUE)
          }
      }

    # draw the calibrated distributions of the dates
    if(length(calhght) > 0) 
      for(i in 1:length(dat$depth))
	{
	  pol <- dat$calib[[i]]
	  pol[,2] <- pol[,2]/max(pol[,2])
	  pol <- cbind(c(pol[,1], pol[nrow(pol):1,1]), 
	    c(dat$depth[[i]]-calhght*pol[,2], dat$depth[[i]]+calhght*pol[nrow(pol):1,2]))
	  polygon(pol, col=calcol, border=calcol)
	}

    # draw the calibrated ranges of the dates
    for(i in 1:length(dat$depth))
      for(j in 1:nrow(dat$hpd[[i]]))
        rect(dat$hpd[[i]][j,1], dat$depth[i]-dat$thick[i]/2, dat$hpd[[i]][j,2], dat$depth[i]+dat$thick[i]/2, lwd=1, lend=2, col=detcol, border=NA)
    if(length(outliers)>0) # any outliers?
      {
        for(i in outliers)
          for(j in 1:nrow(dat$hpd[[i]]))
            rect(dat$hpd[[i]][j,1], dat$depth[i]-dat$thick[i]/2, dat$hpd[[i]][j,2], dat$depth[i]+dat$thick[i]/2, col=outcol, border=outcol, lwd=1, lend=2)
        points(dat$mid[outliers], dat$depth[outliers], cex=outlsize, pch=4, col=outcol)
      }

    # draw the age-depth models, per section if hiatuses were inferred
    if(length(hiatus)>0)
      {
        hiatusseq <- sort(c(range(depthseq), hiatus))
        for(i in 2:length(hiatusseq))
          {
            sec <- calrange[min(which(calrange[,1] > hiatusseq[i-1])):max(which(calrange[,1] < hiatusseq[i])),]
            pol <- cbind(c(sec[,2], sec[nrow(sec):1,3]), c(sec[,1], sec[nrow(sec):1,1]))
            if(plotrange)
              polygon(pol, col=rangecol, border=rangecol)
            lines(sec[,4], sec[,1], lwd=2, col=bestcol)
            abline(h=hiatus, col="grey", lty="dashed")
          }
      } else
      {
        pol <- cbind(c(calrange[,2], calrange[nrow(calrange):1,3]), c(calrange[,1], calrange[nrow(calrange):1,1]))
        if(plotrange)
          polygon(pol, col=rangecol, border=rangecol)
        lines(calrange[,4], calrange[,1], lwd=2, col=bestcol)
      }
  }


# to calibrate individual 14C dates
calibrate <- function(cage=2450, error=50, reservoir=0, sdev=2, steps=1, calmin=c(), calmax=c(), ymin=c(), ymax=c(), times=5, calheight=0.3, expand=0.1, graph=TRUE, storedat=FALSE, xlab=c(), ylab=c(), BCAD=FALSE, title=c(), date.col="red", cc.col=rgb(0,.5,0,.7), dist.col=rgb(0,0,0,.3), sd.col=rgb(0,0,0,.5))
  .calibrate(cage, error, reservoir, sdev, steps, calmin, calmax, ymin, ymax, times, calheight, expand, graph, storedat, xlab, ylab, BCAD, title, date.col, cc.col, dist.col, sd.col)

.calibrate <- function(cage, error, reservoir, sdev, steps, calmin, calmax, ymin, ymax, times, calheight, expand, graph, storedat, xlab, ylab, BCAD, title, date.col, cc.col, dist.col, sd.col)
  {
    # check whether date lies partly or entirely beyond the calibration curve
    if(cage-reservoir-times*error < min(calcurve[,2]+calcurve[,3]) ||
      cage-reservoir+times*error > max(calcurve[,2]-calcurve[,3]))
    if((cage-reservoir-times*error < min(calcurve[,2]-calcurve[,3]) &&
      cage-reservoir+times*error > min(calcurve[,2]-calcurve[,3])) ||
      (cage-reservoir-times*error < max(calcurve[,2]+calcurve[,3]) &&
      cage-reservoir+times*error > max(calcurve[,2]+calcurve[,3])))
        cat("\nDate falls partly beyond calibration curve and will be truncated!")  else
        stop("\nCannot calibrate dates beyond calibration curve!\n\n")

    # calibrate the date and report its highest posterior density (hpd) range
    if(BCAD) calcurve[,1] <- 1950-calcurve[,1]
    if(length(xlab)==0) xlab <- ifelse(BCAD, "cal BC/AD", "cal BP")
    calib <- .caldist(cage, error, steps, times, calcurve, BCAD)
    hpd <- .hpd(calib, sdev, steps)
    colnames(hpd) <- c("calmin", "calmax", "prob")
    dat <- list(calib=calib, hpd=hpd)
    if(storedat) dat <<- dat
    cat("\nmin\tmax\tprob\n")
    for(i in 1:nrow(hpd))
      {
        for(j in 1:3) cat(hpd[i,j], "\t")
        cat("\n")
      }
    cat("\n")

    # produce a graph of the calibrated distribution (default)
    if(graph)
      {
        ifelse(BCAD,
          xrange <- 1950+c((1+expand)*(min(calib[,1])-1950), (1-expand)*(max(calib[,1])-1950)),
        xrange <- c((1+expand)*max(calib[,1]), (1-expand)*min(calib[,1])))
        if(length(calmin) > 0) xrange[2] <- calmin
        if(length(calmax) > 0) xrange[1] <- calmax
        ifelse(BCAD,
          cc <- calcurve[max(which(calcurve[,1] >= min(xrange))):min(which(calcurve[,1] <= max(xrange))),],
          cc <- calcurve[min(which(calcurve[,1] >= min(xrange))):max(which(calcurve[,1] <= max(xrange))),])

      # first plot the calibrated distribution, and its hpd ranges
      par(mar=c(3.5,3,2,1), mgp=c(2,1,0), xaxs="i", xaxt="s", yaxt="n", yaxs="i", bty="l", new=FALSE)
      pol <- cbind(c(calib[,1], calib[nrow(calib):1,1]), c(calib[,2]/max(calib[,2]), rep(0, length=nrow(calib))))
      plot(0, type="n", xlim=xrange, ylim=c(0,1/calheight), xlab="", ylab="")
      polygon(pol, col=dist.col, border=NA)
      for(i in 1:nrow(hpd))
        {
          if(hpd[i,1]==hpd[i,2])
            {
              probs <- calib[which(calib[,1]==hpd[i,1]),]
              lines(rep(probs[1], 2), c(0, probs[2]/max(calib[,2])), col=grey(.5))
            } else
            {
              probs <- calib[which(calib[,1]==hpd[i,1]):which(calib[,1]==hpd[i,2]),]
              pol <- cbind(c(probs[,1], probs[nrow(probs):1,1]), c(probs[,2]/max(calib[,2]), rep(0, length=nrow(probs))))
              polygon(pol, col=sd.col, border=NA)
            }
        }
      lines(calib[,1], calib[,2]/max(calib[,2]))
      abline(h=0)

      # now draw the 14C distribution (normal distribution, on vertical axis)
      par(new=TRUE, yaxt="s", yaxs="r", xaxt="n")
      if(length(title)==0) main <- title
      if(reservoir!=0)
          main <- substitute(cage-res %+-% er, list(cage=cage, er=error, res=reservoir)) else
          main <- substitute(cage %+-% er, list(cage=cage, er=error))
      if(length(ymin)==0) ymin <- min(cc[,2]-sdev*cc[,3], cage-reservoir-sdev*error)
      if(length(ymax)==0) ymax <- max(cc[,2]+sdev*cc[,3], cage-reservoir+sdev*error)
      if(length(ylab)==0) ylab <- expression(paste(""^14, "C BP"))
      plot(0, type="n", xlim=xrange, ylim=c(ymin, ymax), xlab=xlab, ylab=ylab, main=main)
      yage <- (cage-reservoir-5*error):(cage-reservoir+5*error)
      xage <- dnorm(yage, cage-reservoir, error)/max(dnorm(yage, cage-reservoir, error))
      xage <- xrange[1]-((xrange[1]-xrange[2])*calheight)*xage
      pol <- cbind(c(xage, rep(xrange[1], length=length(xage))), c(yage, yage[length(yage):1]))
      polygon(pol, col=dist.col, border="black")

      # draw the highest posterior density (hpd) range of the 14C date
      yage <- (cage-reservoir-sdev*error):(cage-reservoir+sdev*error)
      xage <- dnorm(yage, cage-reservoir, error)/max(dnorm(yage, cage-reservoir, error))
      xage <- xrange[1]-((xrange[1]-xrange[2])*calheight)*xage
      pol <- cbind(c(xage, rep(xrange[1], length=length(xage))), c(yage, yage[length(yage):1]))
      polygon(pol, col=sd.col, border=FALSE)

      # plot the mid and error of the 14C date
      points(xrange[1]-.01*(xrange[1]-xrange[2]), cage, pch=19, col=date.col)
      lines(rep(xrange[1]-.01*(xrange[1]-xrange[2]), 2), c(cage-error, cage+error), lwd=2, col=date.col)

      # now draw the calibration curve
      pol <- cbind(c(calcurve[,1], calcurve[,1][nrow(calcurve):1]),
        c(calcurve[,2]-sdev*calcurve[,3], (calcurve[,2]+sdev*calcurve[,3])[nrow(calcurve):1]))
      polygon(pol, border=cc.col, col=cc.col)
    }
  }


# list the available cores
cores <- list.files("Cores/")


# welcome and choose curve
cat("Hi there, welcome to clam for age-depth modelling.\n")
choosecurve(default=TRUE)
